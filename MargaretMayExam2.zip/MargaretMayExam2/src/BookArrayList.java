import java.text.DecimalFormat;
import java.util.ArrayList;

/**
import java.awt.EventQueue;

 * 
 */

/**
 * @author marga
 *
 */
public class BookArrayList 
{

	/**
	 * 
	 */
	
	// DECLARE VARIABLES SECTION
	static int index;
	static String name;
	static int length;
	static ArrayList<String> aList = new ArrayList<String>();
	
	static int count;
	static int arrayCntr = 0;
	static String [] booksDisplay = new String[30];
	static String [] cntrStr = new String[30];
	
	// DEFINE CONSTRUCTOR
	public BookArrayList(ArrayList<String> al, String bn, int bi, int l)
	{  
	// ASSIGN PASSED PARAMETERS TO INITIALIZE VARIABLES IN THE CONSTRUCTOR
		aList = al;
		name = bn;
		index = bi;
		length = l;
				
	// END OF CONSTRUCTOR BookArrayList	
	}	
	
	
	// SET VARIABLES SECTION - INPUT BY USER
	public void setVar(ArrayList<String> al, String bn, int bi, int l)
	{
		aList = al;
		name = bn;
		index = bi;
		length = l;
		
	}  // END OF SETVAR METHOD
	
	
	// ***************************************************************
	
	
	// RETURN VARIABLES SECTION (GETS)
	
	// Return ArrayList list to main
	public ArrayList<String> getArrayList()
	{
		return aList;
		}
				
	// Return Name to main
	public String getName()
	{
		return name;
	}
				
	// Return Index to main
	public int getIndex()
	{
		return index;
	}
	
	
	// ***************************************************************
	
	
	// getBookLoad Method will load an array so that it can be displayed in a JTable in the GUI
			// Window
			public static String[] getBookLoad(ArrayList<String> al, String bn, int bi, int l)
			{  
				int c = 0;
							
				while (c < length)
				{
						// Read booksArrayList and load booksDisplay array
						booksDisplay[c] = aList.get(c);
				
						c = c + 1;
				}
				// END FOR LOOP for loading the books into an array to send back to main program
		
			return booksDisplay;
			// END getBooksLoad	
			}
	
	
	
	//Load Array to print the Index for each book
			public static String[] getCount(int l)
			{  
				arrayCntr = 1;
				int j = 0; 
				while (j < length)
				{
					cntrStr[j] = Integer.toString(arrayCntr);
					arrayCntr = arrayCntr + 1;
					j = j + 1;
				}
			return cntrStr;
			// END getCount
			}
	
			
			
			
// END OF CLASS BookArrayList
}
